<p align=center><img src="kiwi.png" height="200" width="200"></p1>

**Kiwi** is one of SFU Dodo Club's mascots, and is also our main Discord bot. Kiwi is constantly being updated and is maintend by myself. Kiwi is currently being hosted on heroku.

# Contribute
We welcome changes that benefit the server as a whole! Please feel free to discuss in
our discord server! 

# Commands
Kiwi's functionality ranges from minigames to basic string manipulation. 
